//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//


//Messaging from Page to Live View:
import Foundation
import PlaygroundSupport
PlaygroundPage.current.needsIndefiniteExecution = true
func stretchPizza() {
//    coming soon...
}
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, true, false)
//#-end-hidden-code
//: # The Basics
//: First thing first to cook a pizza is to prepare the pizza dough. This is the basis where all the ingredients will be placed in the next steps.  Pizza Dough is composed by:  1. One Cup (250 ml) warm water 💧 2. One Teaspoon (5 ml) instant yeast. 3. One Teaspoon (5 ml) sugar. 4. Two Cups (500 mil) all-purpose flour.  5. One Teaspoon (5 ml) salt. 🧂  After that you mixed these ingredients, you will get the pizza dough as you can see on the live view side of the screen.   🍕 Goal: You need to stretch the pizza dough in order to to enlarge it and let it assume the common pizza-form.   1.     Set the integer number value (Int) to 5. 2.     Tap Run My Code and discover how much the dough get enlarged. Play with this number to check how the dough change its size.
var timesToStretch: Int = /*#-editable-code*/<#T##Integer Number##Int#>/*#-end-editable-code*/
for i in 1 ... timesToStretch {
    stretchPizza()
}
//#-hidden-code
sendValue(.data(try NSKeyedArchiver.archivedData(withRootObject: timesToStretch, requiringSecureCoding: true)))
//#-end-hidden-code
