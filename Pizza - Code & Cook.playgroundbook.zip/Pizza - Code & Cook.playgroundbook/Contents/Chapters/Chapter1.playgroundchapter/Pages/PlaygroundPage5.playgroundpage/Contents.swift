//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//


//Messaging from Page to Live View:
import Foundation
import PlaygroundSupport
PlaygroundPage.current.needsIndefiniteExecution = true
//#-code-completion(everything, hide)
//#-end-hidden-code
//: # Eat the Pizza
//: Once that you have cooked your pizza correctly, this will be your result. If you didn't prepare a custom pizza in the previous steps, you will see just a classic Margherita.  I've already cut your pizza in four slices for you. Now it's time to enjoy your wonderful creation. Let's eat it and taste it. 😋   What? Do you want to experiment new ingredients on your pizza? You can also go back in the previous pages to change them and bake the entire pizza with different time. Enjoy! 🍕🍕🍕🍕   "Someone said that you can’t buy happiness, but you can buy pizza and that’s kind of the same thing."
