//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//


//Messaging from Page to Live View:
import Foundation
import PlaygroundSupport
PlaygroundPage.current.needsIndefiniteExecution = true
//#-code-completion(everything, hide)
//#-code-completion(literal, show, 50, 100, 150, 200, 300, 350, 400, 500, 1000)
//#-end-hidden-code
//: # Bake the Pizza
//: Now that you have prepared your pizza, you need to bake it. How?  You need an oven. In Italian tradition the oven must be a wood oven, but if you don't have it, you can just use a normal oven.  Baking it's essential to have a crunchy breading italian pizza. In order to do that you should choose carefully how much time you leave the pizza into the oven. If you leave it for too much time, it will burn out. Otherwise if you leave it just for a little while, it will be undercooked. Usually pizza needs from 2 to 3 minutes to have a good taste and aspect.  🔥🔥🔥   🍕 Goal: You need to set a time (seconds) for baking your pizza.  1. Set an Integer Number to the time constant. 2. Tap Run My Code and discover how the pizza will be, with that baking time.
let secondsBaking: Int = /*#-editable-code*//*#-end-editable-code*/
//#-hidden-code
    sendValue(.data(try NSKeyedArchiver.archivedData(withRootObject: secondsBaking, requiringSecureCoding: true)))

if (secondsBaking < 100 || secondsBaking > 200) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: ["It should be a number between 100 and 200."], solution: nil)
} else {
    PlaygroundPage.current.assessmentStatus = .pass(message:"Well done! Perfect! [Next Page](@next).")
}
//#-end-hidden-code



