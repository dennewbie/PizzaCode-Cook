//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//Messaging from Page to Live View:
import Foundation
import PlaygroundSupport
PlaygroundPage.current.needsIndefiniteExecution = true
//#-code-completion(everything, hide)
//#-end-hidden-code
//: # Meet the Pizza
//: Hello little human, 👋 Is this the first time you see a Pizza?  🍕  Wonderful! So you know that it is a flat bread layered with juicy tomato sauce and topped with olive oil, shredded mozzarella cheese, and other optional ingredients such as onion, fries, pepperoni, mushrooms and sometimes … also pineapple.  Pizza shares its origin among two countires: Greece and Italy. But it was majorly the port of Naples (southern city of Italy), from where it all started to become a commercial success. Would you like to learn how to cook a pizza from scratch? Amazing!  🍕 Goal: Let’s find out more about the pizza's ingredients:  1. Tap on any of them to discover it.  Feel free to go to the [Next Page](@next) when you want!
