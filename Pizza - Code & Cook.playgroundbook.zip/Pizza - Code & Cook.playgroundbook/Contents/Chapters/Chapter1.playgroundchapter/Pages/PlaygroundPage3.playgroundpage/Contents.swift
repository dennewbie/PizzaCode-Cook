//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//


//Messaging from Page to Live View:
import Foundation
import PlaygroundSupport
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code
//: # Master Pizza Chef
//: Now it's time to show off your creativity and put some ingredients on the pizza. Remember that each ingredient have its own characteristic and tastes. You can add ingredient by setting "true" near to the relative ingredient field. In order to remove an ingredient from your pizza, just set that value to "false". Now it's your time to shine and become Master Chef of Pizzaaa! Have fun!  🧀 🥫 🌿 🥓 🍈 🍍    🍕 Goal: You need to add some ingredient to the pizza. After that your pizza will be quite ready.  1. Set "true" to add ingredients 2. Set "false" to remove ingredients 3. Tap Run My Code and discover how the pizza will appear with the ingredients that you placed on it.
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, true, false)
var ingredientsOnPizza: [String: Bool] = [
    "isTomatoSauceOnPizza": /*#-editable-code*/true/*#-end-editable-code*/,
    "isCheeseOnPizza": /*#-editable-code*/true/*#-end-editable-code*/,
    "isBasilOnPizza": /*#-editable-code*/true/*#-end-editable-code*/,
    "isOiliveOilOnPizza": /*#-editable-code*/false/*#-end-editable-code*/,
    "isPepperoniOnPizza": /*#-editable-code*/false/*#-end-editable-code*/,
    "isPineappleOnPizza": /*#-editable-code*/false/*#-end-editable-code*/
]
//#-hidden-code
let arrayData = NSKeyedArchiver.archivedData(withRootObject: ingredientsOnPizza)
sendValue(.data(arrayData))
//#-end-hidden-code
