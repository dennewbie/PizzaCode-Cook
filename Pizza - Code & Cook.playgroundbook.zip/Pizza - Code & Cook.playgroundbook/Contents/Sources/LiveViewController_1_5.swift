//
//  LiveViewController_1_4.swift
//  Book_Sources
//
//  Created by Denny Caruso on 20/03/2019.
//

import UIKit
import PlaygroundSupport
import AVFoundation

class LiveViewController_1_5: LiveViewController {
    
    @IBOutlet weak var backPlatePizza: UIImageView!
    var tomatoSauceImageView: UIImageView!
    var mozzarellaCheeseImageView: UIImageView!
    var basilImageView: UIImageView!
    var pepperoniImageView: UIImageView!
    var pineappleImageView: UIImageView!
    var oliveOilImageView: UIImageView!
    
    var shouldRandomisePizza: Int = 0
    var audioPlayer = AVAudioPlayer()
    
    @IBOutlet weak var pizzaCenterImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        backPlatePizza.image = UIImage(named: "platePizza")
        shouldRandomisePizza = 0
        createAnimations()
        
        setupIngredients()
        changeIngredient()
        setMusic()
        
        var bakingType: String?
        
        if let keyValue = PlaygroundPage.current.keyValueStore["bakingType"],
            case .string(let ingredientType) = keyValue {
            bakingType = ingredientType
            
            if bakingType == "bakingType" {
                var bakingTypeInt: Int = Int(bakingType!)!
                createActualPizzaImage(kindOfBake: bakingTypeInt)
            } else {
                shouldRandomisePizza += 6
            }
            switch bakingType {
            case "0":
                pizzaCenterImage.image = UIImage(named: "impasto6")
            case "1":
                pizzaCenterImage.image = UIImage(named: "impasto7")
            case "2":
                pizzaCenterImage.image = UIImage(named: "impasto8")
            default:
                pizzaCenterImage.image = UIImage(named: "impasto7")
                tomatoSauceImageView.isHidden = false
                mozzarellaCheeseImageView.isHidden = false
                basilImageView.isHidden = false
                break
            }
        }
        pizzaCenterImage.image = drawRectangleOnImage(image: pizzaCenterImage.image!)
    }
    
    func drawRectangleOnImage(image: UIImage) -> UIImage {
        let imageSize = image.size
        let scale: CGFloat = 0
        UIGraphicsBeginImageContextWithOptions(imageSize, false, scale)
        
        image.draw(at: CGPoint.zero)
        
        let rectangle = CGRect(x: 0, y: (imageSize.height/2), width: imageSize.width, height: 3)
        let rectangle2 = CGRect(x: (imageSize.width/2), y: 0, width: 3, height: imageSize.height)
        
        UIColor.lightGray.setFill()
        UIRectFill(rectangle)
        UIRectFill(rectangle2)
        
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage!
    }
    
    
    private func createActualPizzaImage(kindOfBake: Int){
        
        pizzaCenterImage.isHidden = false
        changeIngredient()
        if shouldRandomisePizza == 6 {
            pizzaCenterImage.image = UIImage(named: "impasto6")
            tomatoSauceImageView.isHidden = false
            mozzarellaCheeseImageView.isHidden = false
            basilImageView.isHidden = false
            return
        }
        
        switch kindOfBake {
        case 0:
            pizzaCenterImage.image = UIImage(named: "impasto6")
        case 1:
            pizzaCenterImage.image = UIImage(named: "impasto7")
        case 2:
            pizzaCenterImage.image = UIImage(named: "impasto8")
        default:
            pizzaCenterImage.image = UIImage(named: "impasto6")
            tomatoSauceImageView.isHidden = false
            mozzarellaCheeseImageView.isHidden = false
            basilImageView.isHidden = false
        }
        
    }
    
    private func createAnimations(){
        let rotationAnimation = CABasicAnimation(keyPath: "transform.rotation")
        
        rotationAnimation.fromValue = 0.0
        rotationAnimation.toValue = Float.pi * 2.0
        rotationAnimation.duration = 30
        rotationAnimation.repeatCount = Float.infinity
        
        pizzaCenterImage.layer.add(rotationAnimation, forKey: nil)
    }
    
    
    
    private func setupIngredients(){
        tomatoSauceImageView = UIImageView(frame: CGRect(x: pizzaCenterImage.frame.minX / 13, y: pizzaCenterImage.frame.minY / 18, width: 350, height: 350))
        tomatoSauceImageView.image = UIImage(named: "tomatoSauce")
        pizzaCenterImage.addSubview(tomatoSauceImageView)
        tomatoSauceImageView.isHidden = true
        
        mozzarellaCheeseImageView = UIImageView(frame: CGRect(x: pizzaCenterImage.frame.minX / 8, y: pizzaCenterImage.frame.minY / 11, width: 320, height: 320))
        mozzarellaCheeseImageView.image = UIImage(named: "mozarellaPizza")
        pizzaCenterImage.addSubview(mozzarellaCheeseImageView)
        mozzarellaCheeseImageView.isHidden = true
        
        basilImageView = UIImageView(frame: CGRect(x:  pizzaCenterImage.frame.minX / 5, y: pizzaCenterImage.frame.minY / 5, width: 250, height: 250))
        basilImageView.image = UIImage(named: "basilPizza")
        pizzaCenterImage.addSubview(basilImageView)
        basilImageView.isHidden = true
        
        oliveOilImageView = UIImageView(frame: CGRect(x:  pizzaCenterImage.frame.minX / 5, y: pizzaCenterImage.frame.minY / 8, width: 250, height: 250))
        oliveOilImageView.image = UIImage(named: "oliveOilPizza")
        pizzaCenterImage.addSubview(oliveOilImageView)
        oliveOilImageView.isHidden = true
        
        pepperoniImageView = UIImageView(frame: CGRect(x:  pizzaCenterImage.frame.minX / 4, y: pizzaCenterImage.frame.minY / 7, width: 250, height: 250))
        pepperoniImageView.image = UIImage(named: "pepperoniPizza")
        pizzaCenterImage.addSubview(pepperoniImageView)
        pepperoniImageView.isHidden = true
        
        pineappleImageView = UIImageView(frame: CGRect(x:  pizzaCenterImage.frame.minX / 5, y: pizzaCenterImage.frame.minY / 5, width: 250, height: 250))
        pineappleImageView.image = UIImage(named: "pineapplePizza")
        pizzaCenterImage.addSubview(pineappleImageView)
        pineappleImageView.isHidden = true
    }
    
    private func changeIngredient() {
        var tomatoSauce: String?
        
        if let keyValue = PlaygroundPage.current.keyValueStore["tomatoSauce"],
            case .string(let ingredientType) = keyValue {
            tomatoSauce = ingredientType
            
            if tomatoSauce == "tomatoSauce" {
                tomatoSauceImageView.isHidden = false
            } else {
                shouldRandomisePizza += 1
            }
            
        }
        
        var mozzarellaCheese: String?
        if let keyValue = PlaygroundPage.current.keyValueStore["mozarellaPizza"],
            case .string(let ingredientType) = keyValue {
            mozzarellaCheese = ingredientType
            
            if mozzarellaCheese == "mozarellaPizza" {
                mozzarellaCheeseImageView.isHidden = false
            } else {
                shouldRandomisePizza += 1
            }
        }
        
        
        var basil: String?
        if let keyValue = PlaygroundPage.current.keyValueStore["basilPizza"],
            case .string(let ingredientType) = keyValue {
            basil = ingredientType
            
            if basil == "basilPizza" {
                basilImageView.isHidden = false
            } else {
                shouldRandomisePizza += 1
            }
        }
        
        
        var oliveOilPizza: String?
        if let keyValue = PlaygroundPage.current.keyValueStore["oliveOilPizza"],
            case .string(let ingredientType) = keyValue {
            oliveOilPizza = ingredientType
            
            if oliveOilPizza == "oliveOilPizza" {
                oliveOilImageView.isHidden = false
            } else {
                shouldRandomisePizza += 1
            }
        }
        
        var pepperoniPizza: String?
        if let keyValue = PlaygroundPage.current.keyValueStore["pepperoniPizza"],
            case .string(let ingredientType) = keyValue {
            pepperoniPizza = ingredientType
            
            if pepperoniPizza == "pepperoniPizza" {
                pepperoniImageView.isHidden = false
            } else {
                shouldRandomisePizza += 1
            }
        }
        
        
        var pineapplePizza: String?
        
        if let keyValue = PlaygroundPage.current.keyValueStore["pineapplePizza"],
            case .string(let ingredientType) = keyValue {
            pineapplePizza = ingredientType
            
            if pineapplePizza == "pineapplePizza" {
                pineappleImageView.isHidden = false
            } else {
                shouldRandomisePizza += 1
            }
        }
        pizzaCenterImage.image = drawRectangleOnImage(image: pizzaCenterImage.image!)
    }
    
    private func setMusic() {
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "SouthOfTheBorder", ofType: ".mp3")!))
            audioPlayer.prepareToPlay()
            audioPlayer.play()
            audioPlayer.numberOfLoops = -1
        } catch let error {
            print(error.localizedDescription)
        }
    }
}
