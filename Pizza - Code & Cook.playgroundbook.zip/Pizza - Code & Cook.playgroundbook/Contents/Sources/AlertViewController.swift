//
//  AlertViewController.swift
//  Book_Sources
//
//  Created by Denny Caruso on 19/03/2019.
//

import UIKit

class AlertViewController: LiveViewController {
    
    @IBOutlet weak var heightTextLabel: NSLayoutConstraint!
    @IBOutlet weak var labelToImageConstraint: NSLayoutConstraint!
    @IBOutlet weak var titleIngredient: UILabel!
    @IBOutlet weak var imgIngredient: UIImageView!
    @IBOutlet weak var lblIngredient: UILabel!
    var passedImage = UIImage()
    var passedText = String()
    var passedTitle = String()
    var textTemp: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imgIngredient.image = passedImage
        lblIngredient.text = passedText
        titleIngredient.text = passedTitle
        imgIngredient.contentMode = .redraw
    }
    
    
    @IBAction func dismissAction(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        if UIDevice.current.orientation.isLandscape {
            print("Landscape")
            labelToImageConstraint.constant = 20
            heightTextLabel.constant = 250
        } else {
            print("Portrait")
            labelToImageConstraint.constant = 10
            heightTextLabel.constant = 150
        }
    }
}
