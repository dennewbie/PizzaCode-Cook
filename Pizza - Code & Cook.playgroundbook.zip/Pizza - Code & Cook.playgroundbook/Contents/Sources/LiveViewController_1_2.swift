//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Provides supporting functions for setting up a live view.
//

import UIKit
import Foundation
import PlaygroundSupport
import AVFoundation

public class LiveViewController_1_2: LiveViewController {
    
    @IBOutlet weak var impastoImage: UIImageView!
    @IBOutlet weak var widthImpasto: NSLayoutConstraint!
    @IBOutlet weak var heightImpasto: NSLayoutConstraint!
    var audioPlayer = AVAudioPlayer()
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        setAsset()
        setMusic()
    }
    
    private func setAsset() {
        impastoImage.image = UIImage(named: "impasto0")
    }
    
    private func setMusic() {
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "SouthOfTheBorder", ofType: ".mp3")!))
            audioPlayer.prepareToPlay()
            audioPlayer.play()
            audioPlayer.numberOfLoops = -1
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    override public func receive(_ message: PlaygroundValue) {
                guard case .data(let messageData) = message else { return }
                do {
                     if var incomingObject = try NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(messageData) as? Int {
                        if incomingObject > 5 {
                            incomingObject = 5
                        } else if incomingObject < 0 {
                            incomingObject = 0
                        }
                        
                        UIView.animate(withDuration: 3, animations: {
                            self.impastoImage.transform = CGAffineTransform(scaleX: 2.0, y: 2.0)
                        })
                        
                        switch incomingObject {
                        case 0:
                            UIView.animate(withDuration: 3, animations: {
                                self.impastoImage.transform = CGAffineTransform(scaleX: 0.0, y: 0.0)
                            })
                            
                        case 1:
                            UIView.animate(withDuration: 3, animations: {
                                self.impastoImage.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
                            })
                        case 2:
                            UIView.animate(withDuration: 3, animations: {
                                self.impastoImage.transform = CGAffineTransform(scaleX: 2.0, y: 2.0)
                            })
                        case 3:
                            UIView.animate(withDuration: 3, animations: {
                                self.impastoImage.transform = CGAffineTransform(scaleX: 2.8, y: 2.8)
                            })
                        case 4:
                            UIView.animate(withDuration: 3, animations: {
                                self.impastoImage.transform = CGAffineTransform(scaleX: 3.5, y: 3.5)
                            })
                        case 5:
                            UIView.animate(withDuration: 3, animations: {
                                self.impastoImage.transform = CGAffineTransform(scaleX: 4, y: 4)
                            })
                        default:
                            print("Error switch incoming object")
                        }
                        
                        impastoImage.image = UIImage(named: "impasto\(incomingObject)")
                    }
                } catch let error { fatalError("\(error) Unable to receive the message from the Playground page") }
    }
}
