//
//  Prova3ViewController.swift
//  Book_Sources
//
//  Created by Denny Caruso on 19/03/2019.
//

import UIKit
import PlaygroundSupport
import Foundation
import AVFoundation

class LiveViewController_1_1: LiveViewController {
    
    @IBOutlet weak var pepperoniDownConstraint: NSLayoutConstraint!
    @IBOutlet weak var pepperoniButton: UIButton!
    @IBOutlet weak var ananasDownConstraint: NSLayoutConstraint!
    @IBOutlet weak var ananasButton: UIButton!
    @IBOutlet weak var basilTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var basilButton: UIButton!
    @IBOutlet weak var oliveOilTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var oliveOilButton: UIButton!
    @IBOutlet weak var tomatoButton: UIButton!
    @IBOutlet weak var fromageButton: UIButton!
    @IBOutlet weak var pizzaHeight: NSLayoutConstraint!
    @IBOutlet weak var pizzaWidth: NSLayoutConstraint!
    @IBOutlet weak var centerPizza: UIImageView!
    var oldViewDim: CGFloat!
    var audioPlayer = AVAudioPlayer()
    
    var titleFromage = "Cheese"
    var textFromage = "Cheese is a dairy product derived from milk that is produced in a wide range of flavors, textures, and forms. Pizza's cheese is called 'Mozzarella': a white, salty, round cheese made from the buffalo milk."
    
    var titleOliveOil = "Olive Oil"
    var textOliveOil = "Olive oil” is how we refer to the oil obtained from the fruit of olive trees. People have been eating olive oil for thousands of years and it's so popular, thanks to its many proven health benefits and its culinary usefulness."
    
    var titlePepperoni = "Pepperoni"
    var textPepperoni = "Pepperoni is an American variety of salami, made from cured pork and beef mixed together and seasoned with paprika or other chili pepper. Pepperoni is soft, slightly smoky, and bright red in color."
    
    var titleTomato = "Tomato"
    var textTomato = "Tomato Sauce made with a puree of tomatoes (or strained tomatoes) with savory vegetables and other seasonings, can be used on pasta as well as on Pizza."
    
    var titleAnanas = "Pineapple"
    var textAnanas = "A pineapple is a large oval fruit that grows in hot countries. It is sweet, juicy, and yellow inside, and it has a thick brownish skin. It is common to use this ingredient on Hawaian Pizza."
    
    var titleBasil = "Basil"
    var textBasil = "Basil is a bright green, leafy plant. Basil is widely used in Italian cuisine and is often paired with tomatoes, meat, vegetables, cheese, and egg dishes. It gives to the dishes a fresh taste."
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setAssets()
        setMusic()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        createAnimations()
    }
    

    private func setAssets() {
        self.centerPizza.image = UIImage(named: "plateNewPizza")
        
        self.fromageButton.setBackgroundImage(UIImage(named: "newPlateFromage"), for: .normal)
        self.fromageButton.addTarget(self, action: #selector(openView), for: .touchUpInside)
        
        self.tomatoButton.setBackgroundImage(UIImage(named: "newPlateTomato"), for: .normal)
        self.tomatoButton.addTarget(self, action: #selector(openView), for: .touchUpInside)
        
        self.oliveOilButton.setBackgroundImage(UIImage(named: "newPlateOliveOil"), for: .normal)
        self.oliveOilButton.addTarget(self, action: #selector(openView), for: .touchUpInside)
        
        self.basilButton.setBackgroundImage(UIImage(named: "newPlateBasil"), for: .normal)
        self.basilButton.addTarget(self, action: #selector(openView), for: .touchUpInside)
        
        self.pepperoniButton.setBackgroundImage(UIImage(named: "newPlatePepperoni"), for: .normal)
        self.pepperoniButton.addTarget(self, action: #selector(openView), for: .touchUpInside)
        
        self.ananasButton.setBackgroundImage(UIImage(named: "newPlateAnanas"), for: .normal)
        self.ananasButton.addTarget(self, action: #selector(openView), for: .touchUpInside)
        
        createAnimations()
    }
    
    private func setMusic() {
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "SouthOfTheBorder", ofType: ".mp3")!))
            audioPlayer.prepareToPlay()
            audioPlayer.play()
            audioPlayer.numberOfLoops = -1
        } catch let error {
            print(error.localizedDescription)
        }
    }

    
    private func createAnimations(){
        let rotationAnimation = CABasicAnimation(keyPath: "transform.rotation")

        rotationAnimation.fromValue = 0.0
        rotationAnimation.toValue = Float.pi * 2.0
        rotationAnimation.duration = 60
        rotationAnimation.repeatCount = Float.infinity
        
        centerPizza.layer.add(rotationAnimation, forKey: nil)
        fromageButton.layer.add(rotationAnimation, forKey: nil)
        tomatoButton.layer.add(rotationAnimation, forKey: nil)
        ananasButton.layer.add(rotationAnimation, forKey: nil)
        basilButton.layer.add(rotationAnimation, forKey: nil)
        oliveOilButton.layer.add(rotationAnimation, forKey: nil)
        pepperoniButton.layer.add(rotationAnimation, forKey: nil)
    }
    
    override func viewDidLayoutSubviews() {
        let h = self.view.frame.height
        let w = self.view.frame.width
        if w > h {
            oliveOilTopConstraint.constant = 450
            basilTopConstraint.constant = 450
            pepperoniDownConstraint.constant = 450
            ananasDownConstraint.constant = 450
        } else {
            print(w, h)
            if w > 600 {
                oliveOilTopConstraint.constant = 400
                basilTopConstraint.constant = 400
                pepperoniDownConstraint.constant = 400
                ananasDownConstraint.constant = 400
            } else {
                oliveOilTopConstraint.constant = 450
                basilTopConstraint.constant = 450
                pepperoniDownConstraint.constant = 450
                ananasDownConstraint.constant = 450
            }
        let size = min(w, h)
    }
}
    
    
    //MARK: @OBJC Functions
    @objc private func openView(){
        if fromageButton.isTouchInside == true {
            self.performSegue(withIdentifier: "openDetail", sender: fromageButton)
        } else if tomatoButton.isTouchInside == true {
            self.performSegue(withIdentifier: "openDetail", sender: tomatoButton)
        } else if ananasButton.isTouchInside == true {
            self.performSegue(withIdentifier: "openDetail", sender: ananasButton)
        } else if basilButton.isTouchInside == true {
            self.performSegue(withIdentifier: "openDetail", sender: basilButton)
        } else if oliveOilButton.isTouchInside == true {
            self.performSegue(withIdentifier: "openDetail", sender: oliveOilButton)
        } else if pepperoniButton.isTouchInside == true {
            self.performSegue(withIdentifier: "openDetail", sender: pepperoniButton)
        }
        
    }
    
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        guard segue.identifier != nil else { print("There's no segue"); return }
        
        let receiverVC = segue.destination as! AlertViewController
        
        var tappedTag = (sender as! UIButton).tag
        
        switch tappedTag {
        case 1:
            receiverVC.passedImage = UIImage(named: "newPlateFromage")!
            receiverVC.passedText = textFromage
            receiverVC.passedTitle = titleFromage
        case 2:
            receiverVC.passedImage = UIImage(named: "newPlateOliveOil")!
            receiverVC.passedText = textOliveOil
            receiverVC.passedTitle = titleOliveOil
        case 3:
            receiverVC.passedImage = UIImage(named: "newPlatePepperoni")!
            receiverVC.passedText = textPepperoni
            receiverVC.passedTitle = titlePepperoni
        case 4:
            receiverVC.passedImage = UIImage(named: "newPlateTomato")!
            receiverVC.passedText = textTomato
            receiverVC.passedTitle = titleTomato
        case 5:
            receiverVC.passedImage = UIImage(named: "newPlateAnanas")!
            receiverVC.passedText = textAnanas
            receiverVC.passedTitle = titleAnanas
        case 6:
            receiverVC.passedImage = UIImage(named: "newPlateBasil")!
            receiverVC.passedText = textBasil
            receiverVC.passedTitle = titleBasil
        default:
            print("Error getting the sender.")
        }
    }
}
