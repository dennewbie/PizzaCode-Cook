//
//  LiveViewController_1_4.swift
//  Book_Sources
//
//  Created by Denny Caruso on 20/03/2019.
//

import UIKit
import PlaygroundSupport
import AVFoundation

class LiveViewController_1_4: LiveViewController {
    
    @IBOutlet weak var actualPizzaImage: UIImageView!
    @IBOutlet weak var backgroundWoodOven: UIImageView!
    var isButtonClicked: Bool = false
    
    var animation: UIImage!
    var previousPizzaImage: UIImage!
    var buttonStart = UIButton()
    var shouldRandomisePizza: Int = 0
    var tomatoSauceImageView: UIImageView!
    var mozzarellaCheeseImageView: UIImageView!
    var basilImageView: UIImageView!
    var pepperoniImageView: UIImageView!
    var pineappleImageView: UIImageView!
    var oliveOilImageView: UIImageView!
    var audioPlayer = AVAudioPlayer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        actualPizzaImage.image = UIImage(named: "impasto6")
        shouldRandomisePizza = 0
        setupIngredients()
    
        actualPizzaImage.isHidden = true
        buttonStart = UIButton(frame: CGRect(x: self.view.center.x - 100, y: self.view.center.y - 100, width: 200, height: 200))
        buttonStart.backgroundColor = .green
        
        let imagesToChange = [#imageLiteral(resourceName: "woodOvenCarbon1"), #imageLiteral(resourceName: "woodOvenCarbon2"), #imageLiteral(resourceName: "woodOvenCarbon3"), #imageLiteral(resourceName: "woodOvenCarbon4"), #imageLiteral(resourceName: "woodOvenCarbon5")]
        animation = UIImage.animatedImage(with: imagesToChange, duration: 2)
        backgroundWoodOven.image = animation
        backgroundWoodOven.contentMode = .scaleAspectFill
        setMusic()
    }
    
    private func setupIngredients(){
        tomatoSauceImageView = UIImageView(frame: CGRect(x: actualPizzaImage.frame.minX / 13, y: actualPizzaImage.frame.minY / 18, width: 350, height: 350))
        tomatoSauceImageView.image = UIImage(named: "tomatoSauce")
        actualPizzaImage.addSubview(tomatoSauceImageView)
        tomatoSauceImageView.isHidden = true
        
        mozzarellaCheeseImageView = UIImageView(frame: CGRect(x: actualPizzaImage.frame.minX / 8, y: actualPizzaImage.frame.minY / 11, width: 320, height: 320))
        mozzarellaCheeseImageView.image = UIImage(named: "mozarellaPizza")
        actualPizzaImage.addSubview(mozzarellaCheeseImageView)
        mozzarellaCheeseImageView.isHidden = true
        
        basilImageView = UIImageView(frame: CGRect(x:  actualPizzaImage.frame.minX / 5, y: actualPizzaImage.frame.minY / 5, width: 250, height: 250))
        basilImageView.image = UIImage(named: "basilPizza")
        actualPizzaImage.addSubview(basilImageView)
        basilImageView.isHidden = true
        
        oliveOilImageView = UIImageView(frame: CGRect(x:  actualPizzaImage.frame.minX / 5, y: actualPizzaImage.frame.minY / 8, width: 250, height: 250))
        oliveOilImageView.image = UIImage(named: "oliveOilPizza")
        actualPizzaImage.addSubview(oliveOilImageView)
        oliveOilImageView.isHidden = true
        
        pepperoniImageView = UIImageView(frame: CGRect(x:  actualPizzaImage.frame.minX / 4, y: actualPizzaImage.frame.minY / 7, width: 250, height: 250))
        pepperoniImageView.image = UIImage(named: "pepperoniPizza")
        actualPizzaImage.addSubview(pepperoniImageView)
        pepperoniImageView.isHidden = true
        
        pineappleImageView = UIImageView(frame: CGRect(x:  actualPizzaImage.frame.minX / 5, y: actualPizzaImage.frame.minY / 5, width: 250, height: 250))
        pineappleImageView.image = UIImage(named: "pineapplePizza")
        actualPizzaImage.addSubview(pineappleImageView)
        pineappleImageView.isHidden = true
    }
    
    
    private func createActualPizzaImage(kindOfBake: Int){
        actualPizzaImage.isHidden = false
        changeIngredient()
        
        if shouldRandomisePizza == 6 {
            PlaygroundPage.current.keyValueStore["bakingType"] = .string("3")
            actualPizzaImage.image = UIImage(named: "impasto6")
            tomatoSauceImageView.isHidden = false
            mozzarellaCheeseImageView.isHidden = false
            basilImageView.isHidden = false
            return
        }
        
        switch kindOfBake {
        case 0:
            actualPizzaImage.image = UIImage(named: "impasto6")
            PlaygroundPage.current.keyValueStore["bakingType"] = .string("0")
        case 1:
            actualPizzaImage.image = UIImage(named: "impasto7")
            PlaygroundPage.current.keyValueStore["bakingType"] = .string("1")
        case 2:
            actualPizzaImage.image = UIImage(named: "impasto8")
            PlaygroundPage.current.keyValueStore["bakingType"] = .string("2")
        default:
            PlaygroundPage.current.keyValueStore["bakingType"] = .string("3")
            actualPizzaImage.image = UIImage(named: "impasto6")
            tomatoSauceImageView.isHidden = false
            mozzarellaCheeseImageView.isHidden = false
            basilImageView.isHidden = false
        }
    }

    public override func receive(_ message: PlaygroundValue) {
        shouldRandomisePizza = 0
        guard case .data(let arrayData) = message else { return }
        do {
            let secondsBaking = try NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(arrayData) as? Int
            if secondsBaking != nil {
                if (secondsBaking! < 100) {
                    createActualPizzaImage(kindOfBake: 0)
                    print("Too Low")
                }
                if (secondsBaking! >= 100 && secondsBaking! <= 200) {
                    print("Wonderful")
                    createActualPizzaImage(kindOfBake: 1)
                }
                
                if (secondsBaking! > 200) {
                    print("Too much")
                    createActualPizzaImage(kindOfBake: 2)
                }
            }
        } catch let error {
            fatalError("\(error)")
        }
    }
    
    private func changeIngredient() {
        var tomatoSauce: String?
        
        if let keyValue = PlaygroundPage.current.keyValueStore["tomatoSauce"],
            case .string(let ingredientType) = keyValue {
            tomatoSauce = ingredientType
            
            if tomatoSauce == "tomatoSauce" {
                tomatoSauceImageView.isHidden = false
            } else {
                shouldRandomisePizza += 1
            }
        }
        
        var mozzarellaCheese: String?
        if let keyValue = PlaygroundPage.current.keyValueStore["mozarellaPizza"],
            case .string(let ingredientType) = keyValue {
            mozzarellaCheese = ingredientType
            
            if mozzarellaCheese == "mozarellaPizza" {
                
                mozzarellaCheeseImageView.isHidden = false
            } else {
                shouldRandomisePizza += 1
            }
        }
        
        
        var basil: String?
        if let keyValue = PlaygroundPage.current.keyValueStore["basilPizza"],
            case .string(let ingredientType) = keyValue {
            basil = ingredientType
            
            if basil == "basilPizza" {
                basilImageView.isHidden = false
            } else {
                shouldRandomisePizza += 1
            }
        }
        
        
        
        var oliveOilPizza: String?
        if let keyValue = PlaygroundPage.current.keyValueStore["oliveOilPizza"],
            case .string(let ingredientType) = keyValue {
            oliveOilPizza = ingredientType
            
            if oliveOilPizza == "oliveOilPizza" {
                oliveOilImageView.isHidden = false
            } else {
                shouldRandomisePizza += 1
            }
        }
        
        var pepperoniPizza: String?
        if let keyValue = PlaygroundPage.current.keyValueStore["pepperoniPizza"],
            case .string(let ingredientType) = keyValue {
            pepperoniPizza = ingredientType
            
            if pepperoniPizza == "pepperoniPizza" {
                pepperoniImageView.isHidden = false
            } else {
                shouldRandomisePizza += 1
            }
        }
        
        
        var pineapplePizza: String?
        if let keyValue = PlaygroundPage.current.keyValueStore["pineapplePizza"],
            case .string(let ingredientType) = keyValue {
            pineapplePizza = ingredientType
            
            if pineapplePizza == "pineapplePizza" {
                pineappleImageView.isHidden = false
            } else {
                shouldRandomisePizza += 1
            }
        }
    }
    
    private func setMusic() {
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "SouthOfTheBorder", ofType: ".mp3")!))
            audioPlayer.prepareToPlay()
            audioPlayer.play()
            audioPlayer.numberOfLoops = -1
        } catch let error {
            print(error.localizedDescription)
        }
    }
}
