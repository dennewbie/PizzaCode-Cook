//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Provides supporting functions for setting up a live view.
//

import UIKit
import Foundation
import PlaygroundSupport
import AVFoundation

public class LiveViewController_1_3: LiveViewController {
    
    @IBOutlet weak var backPlate: UIImageView!
    @IBOutlet weak var centerPizzaImage: UIImageView!
    @IBOutlet weak var tovagliaImage: UIImageView!
    var tomatoSauceImageView: UIImageView!
    var mozzarellaCheeseImageView: UIImageView!
    var basilImageView: UIImageView!
    var pepperoniImageView: UIImageView!
    var pineappleImageView: UIImageView!
    var oliveOilImageView: UIImageView!
    let lblTitle = UILabel()
    var textTemp: String!
    var audioPlayer = AVAudioPlayer()
    
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        backPlate.image = UIImage(named: "platePizza")
        self.view.layer.zPosition = 0
        tovagliaImage.layer.zPosition = 1
        backPlate.layer.zPosition = 1
        centerPizzaImage.layer.zPosition = 2
        setupIngredients()
        createInternPizza()
        setMusic()
    }
    
    public override func viewDidAppear(_ animated: Bool) {
        NotificationCenter.default.post(name: Notification.Name("NotificationIdentifier"), object: nil)
    }
    
    private func setupIngredients(){
        tomatoSauceImageView = UIImageView(frame: CGRect(x: centerPizzaImage.frame.minX / 13, y: centerPizzaImage.frame.minY / 18, width: 350, height: 350))
        tomatoSauceImageView.image = UIImage(named: "tomatoSauce")
        tomatoSauceImageView.isHidden = true
        
        mozzarellaCheeseImageView = UIImageView(frame: CGRect(x: centerPizzaImage.frame.minX / 8, y: centerPizzaImage.frame.minY / 11, width: 320, height: 320))
        mozzarellaCheeseImageView.image = UIImage(named: "mozarellaPizza")
        mozzarellaCheeseImageView.isHidden = true
        
        basilImageView = UIImageView(frame: CGRect(x:  centerPizzaImage.frame.minX / 5, y: centerPizzaImage.frame.minY / 5, width: 250, height: 250))
        basilImageView.image = UIImage(named: "basilPizza")
        basilImageView.isHidden = true
        
        oliveOilImageView = UIImageView(frame: CGRect(x:  centerPizzaImage.frame.minX / 5, y: centerPizzaImage.frame.minY / 8, width: 250, height: 250))
        oliveOilImageView.image = UIImage(named: "oliveOilPizza")
        oliveOilImageView.isHidden = true
        
        pepperoniImageView = UIImageView(frame: CGRect(x:  centerPizzaImage.frame.minX / 4, y: centerPizzaImage.frame.minY / 7, width: 250, height: 250))
        pepperoniImageView.image = UIImage(named: "pepperoniPizza")
        pepperoniImageView.isHidden = true
        
        pineappleImageView = UIImageView(frame: CGRect(x:  centerPizzaImage.frame.minX / 5, y: centerPizzaImage.frame.minY / 5, width: 250, height: 250))
        pineappleImageView.image = UIImage(named: "pineapplePizza")
        pineappleImageView.isHidden = true
    }
    
    
    var arrayIngredientsAdded: [String] = []
    public override func receive(_ message: PlaygroundValue) {
        guard case .data(let arrayData) = message else { return }
        do {
            let stringArray = try NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(arrayData) as? [String: Bool]
            if stringArray != nil {
                for (key, value) in stringArray! {
                    switch key {
                    case "isTomatoSauceOnPizza":
                        if value == true {
                            centerPizzaImage.addSubview(tomatoSauceImageView)
                            tomatoSauceImageView.isHidden = false
                            tomatoSauceImageView.layer.zPosition = 3
                            arrayIngredientsAdded.append("tomatoSauce")
                        } else {
                            tomatoSauceImageView.isHidden = true
                            arrayIngredientsAdded.removeAll { $0 == "tomatoSauce" }
                            PlaygroundPage.current.keyValueStore["tomatoSauce"] = .string("")
                        }
                    case "isCheeseOnPizza":
                        if value == true {
                            centerPizzaImage.addSubview(mozzarellaCheeseImageView)
                            mozzarellaCheeseImageView.isHidden = false
                            mozzarellaCheeseImageView.layer.zPosition = 4
                            arrayIngredientsAdded.append("mozarellaPizza")
                        } else {
                            mozzarellaCheeseImageView.isHidden = true
                            arrayIngredientsAdded.removeAll { $0 == "mozarellaPizza" }
                            PlaygroundPage.current.keyValueStore["mozarellaPizza"] = .string("")
                        }
                    case "isBasilOnPizza":
                        if value == true {
                            centerPizzaImage.addSubview(basilImageView)
                            basilImageView.isHidden = false
                            basilImageView.layer.zPosition = 5
                            arrayIngredientsAdded.append("basilPizza")
                        } else {
                             basilImageView.isHidden = true
                            arrayIngredientsAdded.removeAll { $0 == "basilPizza" }
                            PlaygroundPage.current.keyValueStore["basilPizza"] = .string("")
                        }
                    case "isOiliveOilOnPizza":
                        if value == true {
                            centerPizzaImage.addSubview(oliveOilImageView)
                            oliveOilImageView.isHidden = false
                            oliveOilImageView.layer.zPosition = 6
                            arrayIngredientsAdded.append("oliveOilPizza")
                        } else {
                            oliveOilImageView.isHidden = true
                            arrayIngredientsAdded.removeAll { $0 == "oliveOilPizza" }
                            PlaygroundPage.current.keyValueStore[""] = .string("oliveOilPizza")
                        }
                    case "isPepperoniOnPizza":
                        if value == true {
                            centerPizzaImage.addSubview(pepperoniImageView)
                            pepperoniImageView.isHidden = false
                            pepperoniImageView.layer.zPosition = 7
                            arrayIngredientsAdded.append("pepperoniPizza")
                        } else {
                            pepperoniImageView.isHidden = true
                            arrayIngredientsAdded.removeAll { $0 == "pepperoniPizza" }
                            PlaygroundPage.current.keyValueStore["pepperoniPizza"] = .string("")
                        }
                    case "isPineappleOnPizza":
                        if value == true {
                            centerPizzaImage.addSubview(pineappleImageView)
                            pineappleImageView.isHidden = false
                            pineappleImageView.layer.zPosition = 8
                            arrayIngredientsAdded.append("pineapplePizza")
                        } else {
                            pineappleImageView.isHidden = true
                            arrayIngredientsAdded.removeAll { $0 == "pineapplePizza" }
                            PlaygroundPage.current.keyValueStore["pineapplePizza"] = .string("")
                        }
                    default:
                        break
                    }
                }
                
                for item in arrayIngredientsAdded {
                    switch item {
                    case "tomatoSauce":
                        PlaygroundPage.current.keyValueStore["tomatoSauce"] = .string("tomatoSauce")
                    case "mozarellaPizza":
                        PlaygroundPage.current.keyValueStore["mozarellaPizza"] = .string("mozarellaPizza")
                    case "basilPizza":
                        PlaygroundPage.current.keyValueStore["basilPizza"] = .string("basilPizza")
                    case "oliveOilPizza":
                        PlaygroundPage.current.keyValueStore["oliveOilPizza"] = .string("oliveOilPizza")
                    case "pepperoniPizza":
                        PlaygroundPage.current.keyValueStore["pepperoniPizza"] = .string("pepperoniPizza")
                    case "pineapplePizza":
                        PlaygroundPage.current.keyValueStore["pineapplePizza"] = .string("pineapplePizza")
                    default:
                        break
                    }
                }
            }
        } catch let error {
            fatalError("\(error)")
        }
    }
    
    
    private func createInternPizza(){
        let pizzaInternImageView: UIImageView = UIImageView(frame: CGRect(x: 0, y: 0, width: self.centerPizzaImage.frame.width, height: self.centerPizzaImage.frame.height))
        pizzaInternImageView.image = UIImage(named: "impasto6")
        
        
        if tomatoSauceImageView.isHidden == true {
            pizzaInternImageView.addSubview(tomatoSauceImageView)
        }

        if mozzarellaCheeseImageView.isHidden == true {
            pizzaInternImageView.addSubview(mozzarellaCheeseImageView)
        }

        if pineappleImageView.isHidden == true {
            pizzaInternImageView.addSubview(pineappleImageView)
        }

        if pepperoniImageView.isHidden == true {
            pizzaInternImageView.addSubview(pepperoniImageView)
        }

        if basilImageView.isHidden == true {
            pizzaInternImageView.addSubview(basilImageView)
        }

        if oliveOilImageView.isHidden == true {
            pizzaInternImageView.addSubview(oliveOilImageView)
        }
        
        
         let receiverVC = LiveViewController_1_4()
         receiverVC.previousPizzaImage = pizzaInternImageView.image
    }
    
    private func setMusic() {
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "SouthOfTheBorder", ofType: ".mp3")!))
            audioPlayer.prepareToPlay()
            audioPlayer.play()
            audioPlayer.numberOfLoops = -1
        } catch let error {
            print(error.localizedDescription)
        }
    }
}

